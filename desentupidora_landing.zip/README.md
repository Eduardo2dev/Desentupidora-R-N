# Landing Page — Desentupidora (One-page)

Estrutura entregue (ZIP):
```
index.html
assets/
  css/style.css
  js/main.js
  img/hero.svg
  img/favicon.svg
README.md
```

## Como usar
1. Extraia o zip.
2. Abra `index.html` em um navegador (não precisa de servidor).
3. Substitua os placeholders no `index.html` por informações reais:
   - `{NOME_EMPRESA}`, `{CIDADE}`, `{TELEFONE}`, `{WHATSAPP}`, `{EMAIL}`, `{HORARIO_FUNCIONAMENTO}`

## Funcionalidades
- CTA para WhatsApp com link `https://wa.me/{WHATSAPP}?text=...`.
- Formulário com validação básica; envia por `mailto:` como fallback.
- FAQ em accordion (acessível).
- FAB do WhatsApp fixo.
- Mapa incorporado usando Google Maps embed (busca por `{CIDADE}`).
- JSON-LD com dados do negócio (substituir placeholders).

## Imagens / Licença
As imagens são ilustrações simples em SVG (placeholder). Se preferir fotos reais, troque `assets/img/hero.svg` por imagens otimizadas (WebP/JPG). Use bancos gratuitos (Unsplash, Pexels) e inclua créditos se necessário.

## Observações técnicas
- Mobile-first e responsivo.
- Sem backend — formulário usa `mailto:` e botão do WhatsApp para contato rápido.
- Acessibilidade básica (semântica, alt, foco por teclado).
